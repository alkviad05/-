// ── Navbar scroll shadow ──
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar?.classList.toggle('scrolled', window.scrollY > 16);
}, { passive: true });

// ── Mobile burger ──
const burger   = document.getElementById('burger');
const navLinks = document.getElementById('nav-links');
burger?.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  burger.classList.toggle('open', open);
  burger.setAttribute('aria-expanded', String(open));
});

// ── Close mobile menu on link click ──
navLinks?.querySelectorAll('a').forEach(a => {
  a.addEventListener('click', () => {
    navLinks.classList.remove('open');
    burger?.classList.remove('open');
  });
});

// ── Auto-dismiss flash messages ──
document.querySelectorAll('.flash').forEach(el => {
  setTimeout(() => el.remove(), 6000);
});
