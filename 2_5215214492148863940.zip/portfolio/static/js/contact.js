// ── Client-side validation for contact form ──
(function () {
  const form      = document.getElementById('contactForm');
  if (!form) return;

  const nameInput  = document.getElementById('name');
  const emailInput = document.getElementById('email');
  const msgInput   = document.getElementById('message');
  const nameErr    = document.getElementById('nameError');
  const emailErr   = document.getElementById('emailError');
  const msgErr     = document.getElementById('msgError');
  const submitBtn  = document.getElementById('submitBtn');

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function setError(input, errEl, msg) {
    input.classList.toggle('invalid', !!msg);
    errEl.textContent = msg || '';
  }

  function validateName()  {
    const v = nameInput.value.trim();
    if (!v)           return setError(nameInput,  nameErr,  'Введите имя.'), false;
    if (v.length < 2) return setError(nameInput,  nameErr,  'Минимум 2 символа.'), false;
    setError(nameInput, nameErr, '');
    return true;
  }

  function validateEmail() {
    const v = emailInput.value.trim();
    if (!v)               return setError(emailInput, emailErr, 'Введите e-mail.'), false;
    if (!EMAIL_RE.test(v))return setError(emailInput, emailErr, 'Некорректный e-mail.'), false;
    setError(emailInput, emailErr, '');
    return true;
  }

  function validateMsg() {
    const v = msgInput.value.trim();
    if (!v)            return setError(msgInput, msgErr, 'Введите сообщение.'), false;
    if (v.length < 10) return setError(msgInput, msgErr, 'Минимум 10 символов.'), false;
    setError(msgInput, msgErr, '');
    return true;
  }

  // Live validation
  nameInput.addEventListener('blur',  validateName);
  emailInput.addEventListener('blur', validateEmail);
  msgInput.addEventListener('blur',   validateMsg);

  // Submit
  form.addEventListener('submit', (e) => {
    const ok = validateName() & validateEmail() & validateMsg();
    if (!ok) { e.preventDefault(); return; }

    // UX: disable button while submitting
    submitBtn.disabled = true;
    submitBtn.querySelector('.btn-text').textContent = 'Отправляем…';
  });
})();
