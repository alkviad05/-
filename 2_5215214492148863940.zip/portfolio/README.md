# Portfolio Flask App

Сайт-визитка на Python Flask с SQLite-базой данных, авторизацией, портфолио и формой обратной связи.

## Быстрый старт

```bash
# 1. Установить зависимости
pip install flask werkzeug

# 2. Запустить
python app.py
```

Откройте http://localhost:5000

## Доступ в панель администратора

URL: http://localhost:5000/login  
Логин: `admin`  
Пароль: `admin123`

Чтобы сменить пароль, задайте переменные окружения перед запуском:
```bash
export ADMIN_PASSWORD="ваш_пароль"
export SECRET_KEY="случайная_строка"
python app.py
```

## Структура проекта

```
portfolio/
├── app.py                  # Flask-приложение (маршруты, ORM, валидация)
├── requirements.txt
├── instance/
│   └── portfolio.db        # SQLite (создаётся автоматически)
├── static/
│   ├── css/style.css
│   └── js/{main,contact}.js
└── templates/
    ├── base.html
    ├── index.html          # Главная / О себе
    ├── portfolio.html      # Портфолио
    ├── contact.html        # Контакты + форма
    ├── login.html
    ├── admin/
    │   ├── base.html
    │   ├── dashboard.html
    │   ├── projects.html
    │   ├── project_form.html
    │   └── messages.html
    └── errors/
        ├── 404.html
        └── 403.html
```

## Функциональность

| Раздел | Описание |
|--------|----------|
| Главная | О себе, стек технологий, хронология опыта |
| Портфолио | Проекты из SQLite (не захардкожены) |
| Контакты | Форма с клиентской (JS) и серверной валидацией → SQLite |
| Админ | Вход, CRUD проектов, просмотр / удаление сообщений |
| БД | SQLite + ручной ORM-слой поверх sqlite3 (паттерн Active Record) |
| Статика | Flask `url_for('static', ...)` — правильная раздача CSS/JS |
| Адаптивность | Мобильное меню, гибкие сетки |

## Производство

```bash
gunicorn -w 4 -b 0.0.0.0:8000 app:app
```
